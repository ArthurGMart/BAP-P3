<?php
$id = $_GET['id'];
$voornaam = $_GET['voornaam'];
$tussenvoegsel = $_GET['tussenvoegsel'];
$achternaam = $_GET['achternaam'];
$mailadres = $_GET['mailadres'];

$id = $_GET['id'];
$dbc = mysqli_connect('localhost', 'root', '', 'arthur_db') or die ('error connecting');
$query = "UPDATE  nieuwsbrief_tutorial ";
$query .= "SET voornaam = '$voornaam', tussenvoegsel = '$tussenvoegsel', achternaam = '$achternaam', mailadres = '$mailadres'";
$result = mysqli_query($dbc, $query) or die ('Error updating.');
header("location: beheren.php");

