<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>NIEUWSBRIEF WEBAPP</title>
</head>
<body>
<h1>NIEUWSBRIEF</h1>
<H2>Voor bezoekers</H2>
<a href="inschrijven.php">Inschrijven</a><br>
<a href="uitschrijven.php">Uitschrijven</a><br>
<h2>Voor admins</h2>
<a href="versturen.php">Nieuwsbrief versturen</a><br>
<a href="beheren.php">Mailingijst beheren</a><br>
</body>
</html>