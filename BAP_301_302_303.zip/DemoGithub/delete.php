<?php
$id = $_GET['id'];
$dbc = mysqli_connect('localhost', 'root', '', 'arthur_db') or die ('error connecting');
$query = "DELETE FROM nieuwsbrief_tutorial WHERE id = '$id'";
$result = mysqli_query($dbc, $query) or die ('Error deleting');
header("location: beheren.php");

